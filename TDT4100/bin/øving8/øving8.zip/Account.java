package �ving8;

public interface Account {
	
	void deposit(double amount);
	void withdraw(double amount);
    double getBalance();
}